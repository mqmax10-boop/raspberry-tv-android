Trailer helper page
-------------------
YouTube trailers show "Error 153" when the app embeds them directly, because the app has no
web (http/https) address. This small page fixes that.

1) Upload the file index.html in this folder to any free HTTPS static host
   (GitHub Pages, Netlify Drop, Cloudflare Pages, Vercel...).
   Supabase Storage / Edge Functions will NOT work (they serve HTML as plain text).
2) Open RaspberryTV-App/index.html and set, near the top:
      var TRAILER_URL="https://YOUR-SITE.example/";
3) Rebuild / reinstall the app.

Test in a browser first:  https://YOUR-SITE.example/?id=dQw4w9WgXcQ
