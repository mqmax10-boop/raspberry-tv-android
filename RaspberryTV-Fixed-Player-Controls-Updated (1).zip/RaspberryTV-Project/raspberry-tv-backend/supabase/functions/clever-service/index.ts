// Raspberry TV - Device Registration & Subscription API
// Supabase Edge Function: clever-service
// Uses the new Supabase Secret API Key.

const SUPABASE_URL = Deno.env.get("SUPABASE_URL");

const secretKeys = JSON.parse(
  Deno.env.get("SUPABASE_SECRET_KEYS") ?? "{}"
);

const SUPABASE_KEY = secretKeys["default"];

if (!SUPABASE_URL || !SUPABASE_KEY) {
  throw new Error("Missing Supabase URL or Secret API Key");
}

const H = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type": "application/json",
  "Cache-Control": "no-store",
};

const out = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: H,
  });

const random7 = () =>
  String(
    crypto.getRandomValues(new Uint32Array(1))[0] %
      9000000 + 1000000
  );

async function dbRequest(
  path: string,
  method = "GET",
  body?: unknown
) {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/${path}`,
    {
      method,
      headers: {
        apikey: SUPABASE_KEY,
        "Content-Type": "application/json",
        Accept: "application/json",
        Prefer: "return=representation",
      },
      body: body === undefined
        ? undefined
        : JSON.stringify(body),
    }
  );

  const text = await response.text();

  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  return {
    ok: response.ok,
    status: response.status,
    data,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: H,
    });
  }

  if (req.method !== "GET") {
    return out({ error: "method_not_allowed" }, 405);
  }

  const id =
    new URL(req.url).searchParams.get("id")?.trim() ?? "";

  if (
    id.length < 4 ||
    id.length > 200 ||
    /[\u0000-\u001f]/.test(id)
  ) {
    return out({ error: "bad_id" }, 400);
  }

  try {
    const query =
      `devices?select=*&duid=eq.${encodeURIComponent(id)}`;

    const found = await dbRequest(query);

    if (!found.ok) {
      return out({
        error: "database_error",
        details: found.data,
      }, 500);
    }

    let d = Array.isArray(found.data)
      ? found.data[0]
      : null;

    if (!d) {
      const configuredDays = Number(
        Deno.env.get("TRIAL_DAYS") ?? 10
      );

      const days = Number.isFinite(configuredDays)
        ? Math.max(1, Math.min(30, Math.floor(configuredDays)))
        : 10;

      const row = {
        duid: id,
        device_id: random7(),
        pin: random7(),
        status: "trial",
        plan: "trial",
        expiry: new Date(
          Date.now() + days * 86400000
        ).toISOString(),
      };

      const inserted = await dbRequest(
        "devices",
        "POST",
        row
      );

      if (!inserted.ok) {
        const retry = await dbRequest(query);

        d = Array.isArray(retry.data)
          ? retry.data[0]
          : null;

        if (!d) {
          return out({
            error: "registration_failed",
            details: inserted.data,
          }, 500);
        }
      } else {
        d = Array.isArray(inserted.data)
          ? inserted.data[0]
          : null;
      }
    }

    if (!d) {
      return out({ error: "device_not_found" }, 500);
    }

    const expired =
      d.status === "blocked" ||
      d.status === "expired" ||
      !d.expiry ||
      new Date(d.expiry).getTime() <= Date.now();

    return out({
      status:
        d.status === "blocked"
          ? "blocked"
          : expired
            ? "expired"
            : d.status,
      plan: d.plan,
      expiry: d.expiry,
      pin: d.pin,
      did: d.device_id,
      pl: d.playlist_days
        ? String(d.playlist_days)
        : "",
      playlist: d.pl_url
        ? {
            n: d.pl_name ?? "",
            u: d.pl_url,
            us: d.pl_user ?? "",
            pw: d.pl_pass ?? "",
            v: d.pl_ver ?? 0,
            sh: d.pl_show ?? true,
            ed: d.pl_edit ?? true,
            dl: d.pl_del ?? true,
          }
        : null,
    });
  } catch (error) {
    console.error("Device function error:", error);
    return out({ error: "server_error" }, 500);
  }
});
