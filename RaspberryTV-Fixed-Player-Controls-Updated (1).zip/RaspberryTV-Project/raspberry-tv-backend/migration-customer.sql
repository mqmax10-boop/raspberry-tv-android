-- Run once on an existing Raspberry TV database.
alter table public.devices add column if not exists customer_name text;
alter table public.devices add column if not exists customer_phone text;
