-- Run this ONCE in Supabase: SQL Editor -> New query -> Run
-- (only needed if you created the devices table before this update)
alter table devices
  add column if not exists pl_name text,
  add column if not exists pl_url  text,
  add column if not exists pl_user text,
  add column if not exists pl_pass text,
  add column if not exists pl_ver  int not null default 0,
  add column if not exists pl_show boolean not null default true,
  add column if not exists pl_edit boolean not null default true,
  add column if not exists pl_del  boolean not null default true;
