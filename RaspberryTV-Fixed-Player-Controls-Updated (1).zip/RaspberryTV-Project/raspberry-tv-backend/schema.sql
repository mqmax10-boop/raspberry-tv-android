-- Raspberry TV initial schema. Run once in a NEW Supabase project.
create table if not exists public.devices (
  id bigint generated always as identity primary key,
  duid text unique not null,
  device_id text unique not null,
  pin text not null,
  status text not null default 'trial' check (status in ('trial','active','expired','blocked')),
  plan text not null default 'trial' check (plan in ('trial','paid')),
  expiry timestamptz not null,
  playlist_days int,
  note text,
  customer_name text,
  customer_phone text,
  pl_name text, pl_url text, pl_user text, pl_pass text,
  pl_ver int not null default 0,
  pl_show boolean not null default true,
  pl_edit boolean not null default true,
  pl_del boolean not null default true,
  created_at timestamptz not null default now()
);

-- Explicit allow-list of administrators. Add the Auth user's UUID here after creating it.
create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.site_admins where user_id = (select auth.uid()));
$$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to authenticated;

alter table public.devices enable row level security;
alter table public.site_admins enable row level security;
drop policy if exists "admin full access" on public.devices;
drop policy if exists "site admins manage devices" on public.devices;
create policy "site admins manage devices" on public.devices
  for all to authenticated using (public.is_site_admin()) with check (public.is_site_admin());
drop policy if exists "admins read own admin record" on public.site_admins;
create policy "admins read own admin record" on public.site_admins
  for select to authenticated using (user_id = (select auth.uid()));

-- The TV calls the Edge Function; it uses the service role and bypasses RLS.
-- Never put the service-role key in the app or dashboard.
