// Raspberry TV Supabase project configuration. Publishable key is safe for client use with RLS.
var SUPABASE_URL = "https://ogihrbbrioofsmxxjglq.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_v7zCdEbSP36EoAsnT3dlCA_DszVGzdh";
