# Raspberry TV

IPTV player for Samsung Tizen TVs, with a free Supabase backend and an admin dashboard.

![Themes](docs/themes.png)

- `RaspberryTV-App/` – Tizen web app (M3U + Xtream, Live/Movies/Series, history, favorites, 3 themes, 6 languages)
- `raspberry-tv-backend/` – subscription API (Supabase Edge Function) + admin dashboard

Start with [`README-FIRST.txt`](README-FIRST.txt).
