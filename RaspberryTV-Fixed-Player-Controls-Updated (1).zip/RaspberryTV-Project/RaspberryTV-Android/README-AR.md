# Raspberry TV – Android (نسخة تجريبية)

هذا مشروع Android Studio يغلّف واجهة Raspberry TV الأصلية داخل Android WebView، ويستخدم نفس ملف الواجهة دون إعادة تصميمه. ملف APK لم يُبنَ بعد في هذه البيئة لعدم توفر Android SDK/Gradle.

## بناء APK
1. افتح مجلد `RaspberryTV-Android` في Android Studio.
2. ثبّت Android SDK 35 عندما يطلبه Android Studio.
3. انتظر Gradle Sync.
4. من Build اختر Build APK(s).
5. جرّب APK على هاتف Android، ثم على Android TV.

## ملاحظات مهمة
- نفس APK يستهدف الهاتف وAndroid TV، والواجهة الأصلية مصممة أساسًا للشاشات الأفقية؛ لذلك التطبيق يفتح بالوضع الأفقي للحفاظ على التصميم.
- Android يستخدم Android ID كمعرّف جهاز DUID، بينما Samsung Tizen يستخدم DUID الخاص بالشاشة.
- مشغل Samsung AVPlay غير متاح على Android؛ سيستخدم التطبيق مسار تشغيل المتصفح الاحتياطي. يجب اختبار توافق روابط البث على أجهزة Android الفعلية.
- قبل الاختبار، ضع عنوان Edge Function الصحيح في متغير API أعلى `app/src/main/assets/index.html`، مثل `https://PROJECT.supabase.co/functions/v1/clever-service`.
- لوحة الإدارة تحتاج تشغيل `migration-customer.sql` مرة واحدة على قاعدة البيانات الحالية. في قاعدة جديدة، شغّل `schema.sql`.
- لا تضع مفتاح Service Role داخل التطبيق أو لوحة الإدارة.

## بناء تلقائي من GitHub
المشروع يحتوي على workflow في `.github/workflows/android-apk.yml` لبناء APK تجريبي تلقائيًا عند تشغيل Actions يدويًا أو تحديث ملفات Android. بعد رفع المشروع إلى مستودع GitHub:
1. افتح تبويب Actions.
2. اختر Build Raspberry TV Android APK ثم Run workflow.
3. بعد نجاح العملية افتح نتيجة التشغيل وحمّل Artifact باسم RaspberryTV-Android-test-APK.
4. فك ضغط Artifact وثبّت `app-debug.apk` على الهاتف أو Android TV.
