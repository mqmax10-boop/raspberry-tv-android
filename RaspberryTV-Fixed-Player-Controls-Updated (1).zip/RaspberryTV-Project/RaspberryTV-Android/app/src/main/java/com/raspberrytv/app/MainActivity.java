package com.raspberrytv.app;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.os.Build;
import android.util.Rational;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.KeyEvent;
import android.view.View;
import android.view.TextureView;
import android.widget.FrameLayout;
import android.graphics.Color;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private TextureView videoTexture;
    private ExoPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile long nativePosition = 0;
    private volatile long nativeDuration = 0;
    private volatile boolean nativePlaying = false;
    private float nativeVolume = 1f;
    private boolean nativeMuted = false;
    private final Runnable positionUpdater = new Runnable() {
        @Override public void run() {
            if (player != null) {
                nativePosition = player.getCurrentPosition();
                long d = player.getDuration();
                nativeDuration = (d == androidx.media3.common.C.TIME_UNSET) ? 0 : Math.max(0, d);
                nativePlaying = player.isPlaying();
            }
            handler.postDelayed(this, 500);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        root = new FrameLayout(this);
        videoTexture = new TextureView(this);
        videoTexture.setBackgroundColor(Color.BLACK);
        videoTexture.setVisibility(View.GONE);
        root.addView(videoTexture, new FrameLayout.LayoutParams(-1, -1));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DeviceBridge(), "AndroidDevice");
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        webView.requestFocus(View.FOCUS_DOWN);
        webView.loadUrl("file:///android_asset/index.html");
        handler.post(positionUpdater);
    }

    private void ensurePlayer() {
        if (player != null) return;
        player = new ExoPlayer.Builder(this).build();
        player.setVideoTextureView(videoTexture);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) runJs("window.onNativePlaybackReady&&window.onNativePlaybackReady()");
            }
            @Override public void onPlayerError(PlaybackException error) {
                nativePlaying = false;
                runJs("window.onNativePlaybackError&&window.onNativePlaybackError()");
            }
        });
    }
    private void runJs(String js) {
        if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    public class DeviceBridge {
        @JavascriptInterface public String getDuid() {
            String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            return "android-" + (id == null ? "unknown" : id);
        }
        @JavascriptInterface public void playNative(String url, long positionMs) {
            runOnUiThread(() -> {
                try {
                    ensurePlayer();
                    videoTexture.setVisibility(View.VISIBLE);
                    player.setMediaItem(MediaItem.fromUri(url));
                    player.prepare();
                    if (positionMs > 0) player.seekTo(positionMs);
                    player.play();
                } catch (Exception e) {
                    runJs("window.onNativePlaybackError&&window.onNativePlaybackError()");
                }
            });
        }
        @JavascriptInterface public void stopNative() {
            runOnUiThread(() -> {
                if (player != null) player.stop();
                nativePlaying = false; nativePosition = 0; nativeDuration = 0;
                if (videoTexture != null) videoTexture.setVisibility(View.GONE);
            });
        }
        @JavascriptInterface public void toggleNative() {
            runOnUiThread(() -> { if (player != null) { if (player.isPlaying()) player.pause(); else player.play(); } });
        }
        @JavascriptInterface public void seekNative(long positionMs) {
            runOnUiThread(() -> { if (player != null) player.seekTo(Math.max(0, positionMs)); });
        }
        @JavascriptInterface public void adjustVolumeNative(float delta) {
            runOnUiThread(() -> { nativeMuted = false; nativeVolume = Math.max(0f, Math.min(1f, nativeVolume + delta)); if (player != null) player.setVolume(nativeVolume); });
        }
        @JavascriptInterface public void toggleMuteNative() {
            runOnUiThread(() -> { nativeMuted = !nativeMuted; if (player != null) player.setVolume(nativeMuted ? 0f : nativeVolume); });
        }
        @JavascriptInterface public long getNativePosition() { return nativePosition; }
        @JavascriptInterface public long getNativeDuration() { return nativeDuration; }
        @JavascriptInterface public boolean isNativePlaying() { return nativePlaying; }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (webView != null) webView.dispatchKeyEvent(event);
        return super.onKeyDown(keyCode, event);
    }
    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && webView != null) {
            webView.evaluateJavascript("window.__rtvIsPlaying ? window.__rtvIsPlaying() : false", value -> {
                if ("true".equals(value)) {
                    try {
                        PictureInPictureParams params = new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build();
                        enterPictureInPictureMode(params);
                    } catch (Exception ignored) { }
                }
            });
        }
    }
    @Override public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, android.content.res.Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        if (webView != null) webView.evaluateJavascript("document.body.classList.toggle('pip-mode', " + isInPictureInPictureMode + ")", null);
    }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("if(typeof back==='function'){back()}else{history.back()}", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        handler.removeCallbacks(positionUpdater);
        if (player != null) { player.release(); player = null; }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
