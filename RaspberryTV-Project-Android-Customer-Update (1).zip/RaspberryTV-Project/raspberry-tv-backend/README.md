# Raspberry TV – Backend (Supabase, free tier)

Subscription API for the TV app + an admin dashboard.

| Path | Purpose |
|---|---|
| `schema.sql` | Creates the `devices` table and its security rules |
| `supabase/functions/device/index.ts` | API the TV calls: registers the device, starts the trial, returns status |
| `supabase/config.toml` | Lets the TV call the function without a login token |
| `migration-playlist.sql` | Run once if your `devices` table already exists (adds the playlist columns) |
| `admin/index.html` + `admin/config.js` | Dashboard: view devices, renew, block, edit date, notes, **set the playlist of a device** |

Setup steps are in `../README-FIRST.txt`.

## API
`GET {SUPABASE_URL}/functions/v1/device?id=<TV DUID>`
```json
{"status":"active|trial|expired","plan":"trial|paid","expiry":"2026-11-03T00:00:00Z","pin":"7838564","did":"6818649","pl":"","playlist":{"n":"Provider","u":"http://server:80","us":"user","pw":"pass","v":1,"sh":true,"ed":true,"dl":true}}
```
`playlist` is `null` when none is set. `sh` / `ed` / `dl` = the user may see the server data / edit / delete the playlist (set per device in the dashboard). `v` goes up every time you save the playlist in the dashboard: the app adds the playlist once per version, so a user can edit or delete it freely and it only comes back (updated) when you save it again.
Optional secret: `TRIAL_DAYS` (default 10).

## Security notes
- Playlist credentials are stored as plain text in the `devices` table. Only users explicitly listed in `site_admins` can access the dashboard table. The TV receives its own playlist through the public Edge Function using its DUID; treat device identifiers as private. The service-role key must remain an Edge Function secret.
- Disable public sign-ups in Supabase Auth and create only your admin user.
- The public first-registration endpoint can still be spammed with fabricated DUIDs. Before public launch, add rate limiting / abuse protection (for example an API gateway or CAPTCHA-backed activation flow); DUID alone is not proof of device authenticity. The app now fails closed if the API is missing or unreachable.


## بيانات العملاء وتفعيل جهاز يدويًا
- في قاعدة موجودة شغّل `migration-customer.sql` مرة واحدة لإضافة `customer_name` و`customer_phone`.
- في قاعدة جديدة شغّل `schema.sql` المحدّث.
- لوحة الإدارة تحتوي الآن على زر `تفعيل جهاز جديد`، ويطلب DUID ومدة الاشتراك وبيانات العميل الاختيارية.
