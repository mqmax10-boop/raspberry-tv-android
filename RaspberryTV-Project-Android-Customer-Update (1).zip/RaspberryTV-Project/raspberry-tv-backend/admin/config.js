// Supabase -> Project Settings -> API. The anon key is public by design (protected by RLS + login).
var SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
var SUPABASE_ANON_KEY = "YOUR-ANON-KEY";
