// GET /functions/v1/device?id=<TV DUID>
// Public TV registration endpoint. The service-role key stays server-side.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const url = Deno.env.get("SUPABASE_URL");
const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
if (!url || !key) throw new Error("Missing Supabase server environment variables");
const sb = createClient(url, key, { auth: { persistSession: false } });
const H = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type": "application/json",
  "Cache-Control": "no-store",
};
const out = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: H });
const random7 = () => String(crypto.getRandomValues(new Uint32Array(1))[0] % 9_000_000 + 1_000_000);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: H });
  if (req.method !== "GET") return out({ error: "method_not_allowed" }, 405);
  const id = new URL(req.url).searchParams.get("id")?.trim() ?? "";
  if (id.length < 4 || id.length > 200 || /[\u0000-\u001f]/.test(id)) return out({ error: "bad_id" }, 400);

  const found = await sb.from("devices").select("*").eq("duid", id).maybeSingle();
  if (found.error) return out({ error: "database_error" }, 500);
  let d = found.data;

  if (!d) {
    const configuredDays = Number(Deno.env.get("TRIAL_DAYS") ?? 10);
    const days = Number.isFinite(configuredDays) ? Math.max(1, Math.min(30, Math.floor(configuredDays))) : 10;
    const row = { duid: id, device_id: random7(), pin: random7(), status: "trial", plan: "trial",
      expiry: new Date(Date.now() + days * 86_400_000).toISOString() };
    const inserted = await sb.from("devices").insert(row).select("*").single();
    if (inserted.error) {
      // A parallel first request may have inserted the same DUID. Re-read instead of
      // creating a second identity or silently generating different credentials.
      const retry = await sb.from("devices").select("*").eq("duid", id).maybeSingle();
      if (retry.error || !retry.data) return out({ error: "registration_failed" }, 500);
      d = retry.data;
    } else d = inserted.data;
  }

  if (!d) return out({ error: "device_not_found" }, 500);
  const expired = d.status === "blocked" || d.status === "expired" || !d.expiry || new Date(d.expiry).getTime() <= Date.now();
  return out({
    status: d.status === "blocked" ? "blocked" : expired ? "expired" : d.status,
    plan: d.plan, expiry: d.expiry, pin: d.pin, did: d.device_id,
    pl: d.playlist_days ? String(d.playlist_days) : "",
    playlist: d.pl_url ? { n: d.pl_name ?? "", u: d.pl_url, us: d.pl_user ?? "", pw: d.pl_pass ?? "",
      v: d.pl_ver ?? 0, sh: d.pl_show ?? true, ed: d.pl_edit ?? true, dl: d.pl_del ?? true } : null,
  });
});
